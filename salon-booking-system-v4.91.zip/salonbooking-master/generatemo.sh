msgcat languages/salon-booking-system-en_US.po | msgfmt -o languages/salon-booking-system-en_US.mo -
msgcat languages/salon-booking-system-en_EN.po | msgfmt -o languages/salon-booking-system-en_EN.mo -
msgcat languages/salon-booking-system-it_IT.po | msgfmt -o languages/salon-booking-system-it_IT.mo -
msgcat languages/salon-booking-system-de_DE.po | msgfmt -o languages/salon-booking-system-de_DE.mo -
msgcat languages/salon-booking-system-es_ES.po | msgfmt -o languages/salon-booking-system-es_ES.mo -
msgcat languages/salon-booking-system-fr_FR.po | msgfmt -o languages/salon-booking-system-fr_FR.mo -

