<?php
/**
 * Do not put custom translations here. They will be deleted on Salon Booking System  updates.
 *
 * Keep custom translations in /wp-content/languages/sln/
 */