<?php

class SLN_Constants
{
	const HOURS_BEFORE_FROM_ALWAYS = '+30 minutes';
	const HOURS_BEFORE_TO_ALWAYS   = '+1 year';
	const BREAK_DURATION_MAX       = '03:00';
	const DEFAULT_INTERVAL         = 15;
}
