<?php

class SLN_Helper_AvailabilityFuncs
{
} 