<?php class SLN_Admin_SettingTabs_DocumentationTab extends SLN_Admin_SettingTabs_AbstractTab{
	public function process(){}
} ?>