<?php

class SLN_Exception extends Exception
{
    
}