<?php

class SLN_Action_Sms_Exception extends Exception
{
}
